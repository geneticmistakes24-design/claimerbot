package com.example.screenocr

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

@Suppress("DEPRECATION")
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var historyView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Screen OCR\n\n" +
                "1. Выдай разрешение «Поверх других окон».\n" +
                "2. Нажми «Старт» и разреши запись ВСЕГО экрана.\n" +
                "3. Поверх видео появится красная рамка. Двигай её, тяни красный квадрат в углу, " +
                "чтобы изменить размер. Наведи на место, где появляется надпись.\n" +
                "4. В плавающей панели нажми «▶ Слежка». Новый текст в рамке будет копироваться сам."
        })

        root.addView(Button(this).apply {
            text = "1. Разрешить поверх других окон"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                )
            }
        })
        root.addView(Button(this).apply {
            text = "2. Старт"
            setOnClickListener { onStartClicked() }
        })
        root.addView(Button(this).apply {
            text = "Стоп"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })

        status = TextView(this).apply { text = "Готово" }
        root.addView(status)

        historyView = TextView(this).apply { setTextIsSelectable(true) }
        val scroll = ScrollView(this)
        scroll.addView(historyView)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        }
    }

    override fun onResume() {
        super.onResume()
        historyView.text = OverlayService.history.toString()
    }

    private fun onStartClicked() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала выдай разрешение «Поверх других окон»", Toast.LENGTH_LONG).show()
            return
        }
        if (Langs.ready(this)) {
            requestCapture()
            return
        }
        status.text = "Скачиваю языки для распознавания..."
        Thread {
            val ok = Langs.download(this) { msg -> runOnUiThread { status.text = msg } }
            runOnUiThread {
                if (ok) {
                    status.text = "Языки скачаны"
                    requestCapture()
                }
            }
        }.start()
    }

    private fun requestCapture() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1) {
            if (resultCode == RESULT_OK && data != null) {
                val i = Intent(this, OverlayService::class.java)
                    .putExtra(OverlayService.EXTRA_CODE, resultCode)
                    .putExtra(OverlayService.EXTRA_DATA, data)
                startForegroundService(i)
                moveTaskToBack(true)
            } else {
                status.text = "Доступ к записи экрана не выдан"
            }
        }
    }
}
