package com.example.screenocr

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View

/**
 * Красная рамка. Рисуется по краю окна, а область для OCR берётся ВНУТРИ рамки,
 * поэтому сама рамка в распознавание не попадает.
 * В режиме настройки: тянем за рамку/тело — двигаем, тянем за красный квадрат справа внизу — меняем размер.
 */
class FrameView(ctx: Context, val borderPx: Int) : View(ctx) {

    var editMode = true
        set(value) {
            field = value
            invalidate()
        }

    var onDrag: ((Int, Int) -> Unit)? = null
    var onResize: ((Int, Int) -> Unit)? = null

    private val stroke = Paint().apply {
        color = Color.RED
        style = Paint.Style.STROKE
        strokeWidth = borderPx.toFloat()
    }
    private val tint = Paint().apply { color = 0x33FF0000 }
    private val handle = Paint().apply { color = Color.RED }
    private val handleSize = borderPx * 9

    private var lastX = 0f
    private var lastY = 0f
    private var resizing = false

    override fun onDraw(c: Canvas) {
        val h = borderPx / 2f
        c.drawRect(h, h, width - h, height - h, stroke)
        if (editMode) {
            c.drawRect(
                borderPx.toFloat(), borderPx.toFloat(),
                (width - borderPx).toFloat(), (height - borderPx).toFloat(), tint
            )
            c.drawRect(
                (width - handleSize).toFloat(), (height - handleSize).toFloat(),
                width.toFloat(), height.toFloat(), handle
            )
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!editMode) return false
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.rawX
                lastY = e.rawY
                resizing = e.x > width - handleSize && e.y > height - handleSize
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = (e.rawX - lastX).toInt()
                val dy = (e.rawY - lastY).toInt()
                lastX += dx
                lastY += dy
                if (resizing) onResize?.invoke(dx, dy) else onDrag?.invoke(dx, dy)
            }
        }
        return true
    }
}
