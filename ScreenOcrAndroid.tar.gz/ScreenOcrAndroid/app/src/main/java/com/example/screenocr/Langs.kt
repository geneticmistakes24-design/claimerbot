package com.example.screenocr

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Языковые файлы Tesseract скачиваются один раз и лежат в filesDir/tessdata. */
object Langs {
    private val codes: List<String> get() = Config.LANGS.split("+")

    private fun file(ctx: Context, code: String) =
        File(File(ctx.filesDir, "tessdata"), "$code.traineddata")

    private fun ok(f: File) = f.exists() && f.length() > 100_000

    fun ready(ctx: Context): Boolean = codes.all { ok(file(ctx, it)) }

    fun download(ctx: Context, progress: (String) -> Unit): Boolean {
        File(ctx.filesDir, "tessdata").mkdirs()
        for (code in codes) {
            val target = file(ctx, code)
            if (ok(target)) continue
            progress("Скачиваю язык: $code ...")
            val tmp = File(target.path + ".part")
            try {
                val url = "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/$code.traineddata"
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 20000
                conn.readTimeout = 30000
                conn.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
                conn.disconnect()
                if (!tmp.renameTo(target)) return false
            } catch (e: Exception) {
                tmp.delete()
                progress("Ошибка загрузки ($code): ${e.message}")
                return false
            }
        }
        return true
    }
}
